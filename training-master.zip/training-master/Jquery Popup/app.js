
$(document).ready(function(){

    //click event of first child of class button 
    $('.button').first().click(function(){
        //apply css property to popup on click
        $('.popup').css('display', 'block');
    });

    //click event of last child of class button
    $('.button').last().click(function(){
        //applying css property to popup on click
        $('.popup').css('display', 'none');
    });
    
});