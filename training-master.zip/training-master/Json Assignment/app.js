//Page 1

//validation of UI form
//array for storing the details of dynamic form  
let formDetails = []; 
$inputType = $('#inputType');
$boxList = $('.boxList');
$boxLabel = $('#boxLabel');
$addButton = $('#addInput');
//select('#inputType') tag onchange event for select checbox and radio 
$inputType.off('change').on('change',function()
{
    //condition for inputType = checkbox
    if($inputType.children('option:selected').val() === 'Checkbox')
    {
        $boxList.css('display','block');
        $boxLabel.off('blur').on('blur',function(){
            //clear all the inputs
            $('.boxInputs').remove();
            let type = "check";
            genInput($boxLabel,type);
        });
        
    }
    //condition for inputType = radio
    else if($inputType.children('option:selected').val() === 'Radio')
    {
        $boxList.css('display','block');
        $boxLabel.off('blur').on('blur',function(){
            //clear all the inputs
            $('.boxInputs').remove();
            let type = "radio";
            genInput($boxLabel,type);
        });
        
    }
    //condition if inputType = select
    else if($inputType.children('option:selected').val() === 'Select')
    {
        $boxList.css('display','block');
        $boxLabel.off('blur').on('blur',function(){
            $('.boxInputs').remove();
            //clear all input labels
            $('boxInputs').remove();
            let type = "select";
            genInput($boxLabel,type);
        });
    }
    else{
        //clear the no of box field
        $boxList.css('display','none');
    }
});
    
//function for taking multiple lable input for check selct and radio.
function genInput($boxLabel, type)
{
    for(let i=0;i<$boxLabel.val();i++)
    {
        //create all input after all the box label
        $boxLabel.after(`<div class="boxInputs field">
        <label class="label">${i}</label>
        <input type="text" class="${type} input" />
        </div>`);
        $('.boxInputs').val('');
    }
}
//adding the input 
$addButton.off('click').on('click',function()
{
    //check for change of Select('#inputType')
    if($inputType.children('option:selected').val() === 'input-type')
    {
        alert('choose an input type');
    }
    //validation for blank
    if($('#labelText').val() === '')
    {
        alert($('#labelText').attr('name')+' cannot be blank');
    } 
    else
    {   //declaring the parameters of dynamoic form
        let  formParams = ["control", "label", "validation","required"];
        //object for storing the details
        let detail1 = {};
        //condition for checkbox
        if($inputType.val() === 'Checkbox')
        {
            //an object for multiple checkbox label values
            let label = {};
            let $inputSelector = $('.check');
            let type = 'box';
            pushInput(label, detail1, $inputSelector, type);                 
        }
        else if($inputType.val() === 'Radio')
        {
            //and object for multiple radio button  label values
            let radioLabel = {};
            $inputSelector = $('.radio');
            type = 'btn';
            pushInput(radioLabel, detail1, $inputSelector, type);
        }        
        else if($inputType.val() === 'Select')
        {   
            let option = {};
            $inputSelector = $('.select');
            type='options';
            pushInput(option, detail1, $inputSelector, type);
        }
        if($('#required').prop('checked') === true)
        {
            detail1[formParams[3]] = 'yes';
        }
        else
        {
            detail1[formParams[3]] ='no';
        } 
        $('.imp').each(function(index)
        {   
           detail1[formParams[index]] = $(this).val();  
        });
        formDetails.push(detail1);
    }      
});
//function for pushing all the elements in the formDetails array
function pushInput(label,detail1,$inputSelector,type)
{
    $inputSelector.each(function(index)
    {
        label[`label${index}`] = $(this).val();
        detail1[type] = label;
    }); 
}
//button function to generate json code
$('#generateJson').off('click').on('click',function()
{
    $('#json-code').val(JSON.stringify(formDetails)); 
});



//Page 2

$('#designButton').off('click').on('click',function()
{
    //disable
    $('#designButton').prop('disabled',true);
    //variables
    //first texares
    let $inputCode = $('#input-code').val();
    //json array after parsing first textarea
    formDetails = JSON.parse($inputCode);
    //div with class formresult
    $formResult = $('.formResult');
    //each Loop formDetails parsed from first textarea
    $.each(formDetails, function(index)
    {
        //condition for control type = text
        if(formDetails[index].control === 'Input')
        {
            let type = "text";
            createInput(type, formDetails[index].label,formDetails[index].required, formDetails[index].validation);      
        }
        //condition when control type = number
        else if(formDetails[index].control === 'Number')
        {
            type = "number";
            createInput(type, formDetails[index].label,formDetails[index].required,formDetails[index].validation);
        }
        //condition for control type = textarea
        if(formDetails[index].control === 'Textarea')
        {
            //check for required field
            if(formDetails[index].required === 'yes')
            $formResult.append(`<div class="field"><label class="label"><span style="color:red">*</span>${formDetails[index].label}:</label><textarea class="input" rows=10 cols=30 placeholder = "${formDetails[index].label}" validation-type="${formDetails[index].validation}"></textarea></div>`);   
            else
            $formResult.append(`<div class="field"><label class="label">${formDetails[index].label}:</label><textarea class="input" rows=10 cols=30 placeholder = "${formDetails[index].label}" validation-type="${formDetails[index].validation}"></textarea></div>`);   
        }
        //condition for control type = checkbox
        else if(formDetails[index].control === 'Checkbox')
        {
            //get length of object haiving multiple labels for checkbox 
            let boxLength = Object.keys(formDetails[index].box).length;
            type = "checkbox";
            createMultipleInput(boxLength, type, formDetails[index].label, formDetails[index].box, formDetails[index].required);
        }
        //condition for control type = radio
        else if(formDetails[index].control === 'Radio')
        {
            //get length of object having multiple labels for radio 
            let btnLength = Object.keys(formDetails[index].btn).length;
            type = "radio";
            createMultipleInput(btnLength, type, formDetails[index].label,formDetails[index].btn, formDetails[index].required);
        }
        //condition for control type = select
        else if(formDetails[index].control === 'Select')
        {
            //get the length of the object having multiple options for select
            let boxLength = Object.keys(formDetails[index].options).length;
            //check for required field
            if(formDetails[index].required === 'yes')
                $formResult.append(`<div class="field"><label class="label"><span style="color:red">*</span>${formDetails[index].label}</label><select class="input ${formDetails[index].label}"></select></div>`);
            else
                $formResult.append(`<div class="field"><label class="label">${formDetails[index].label}</label><select class="input ${formDetails[index].label}"></select></div>`);
            for(let i = 0; i < boxLength; i++)
            {
                $(`.${formDetails[index].label}`).append(`<option value="${i}">${formDetails[index].options[`label${i}`]}</option></br>`);
            }
        }              
    });
});

//function for simple input types such as text and number(not for checkbox).
function createInput(type, label, required, validation)
{
    // check for required field              
    if(required === 'yes')
        $formResult.append(`<div class="field"><label class="label"><span style="color:red">*</span>${label}</label><input type="${type}" class="input" validation-type="${validation}"></div>`);
    else
        $formResult.append(`<div class="field"><label class="label">${label}</label><input type="${type}" class="input" validation-type="${validation}"></div>`);
}
//creating multiple inputs for checkbox and radio
function createMultipleInput(length, type, label, objectLabels, required)
{
    //check for required field 
    if(required === 'yes')
        $formResult.append(`<div class="field ${label}"><span style="color:red">*</span>${label}</div>`);
    else
        $formResult.append(`<div class="field ${label}">${label}</div>`);
    for(let i = 0; i < length; i++)
    {
        $(`.${label}`).after(`<label class="label">${objectLabels[`label${i}`]}</label><input type="${type}" class="${type}" name="${label}"></br>`);
    }
}

//blur event for the elements present in the div having class formResult
$('.formResult .input').off('blur').on('blur',function()
{
   //blank validation (by default)
    blankValidation($(this));
    //number validation
    if($(this).attr('validation-type') === 'number-validation')
    {
        numberValidation($(this));
    }
    //email validation
    if($(this).attr('validation-type')=== 'Email-validation')
    {
        emailValidation($(this))
    } 
    
});

//validation for blank in form
function blankValidation($input)
{
    if($input.val() === '')
    {
        $input.css('border','5px solid #E98074');
    }
    else
    {
        $input.css('border','none');
    }
}
//validation for phone number
function numberValidation($input)
{
    if($input.val().length !=10 || $.isNumeric($input.val()) === false)
    {
        $input.css('border','5px solid #E98074');
    }
    else
    {
        $input.css('border','none');
    }
}
//validation for Email
function emailValidation($input)
{
    //regex for email
    let emailid = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (!$input.val().match(emailid))
    {
        $input.css('border','5px solid #E98074');
    }
    else
    {
        $input.css('border','none');
    }
}