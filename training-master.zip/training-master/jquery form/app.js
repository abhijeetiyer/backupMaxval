//array of input fields 
const fields = [$('#continent'), $('#capital'), $('#currency'), $('#pm-name')];
/*change event in select-country*/
$('#select-country').change(function(){  
    //if option value India 
    if($(this).children('option:selected').val() === 'india')
   {
        $("#continent").val('Asia');
        $('#capital').val('Delhi');
        $('#currency').val('rupees');
        $('#pm-name').val('Narendra Modi');
   }
    //if option value Russia 
   else if($(this).children('option:selected').val() === 'Russia')
   {
        $("#continent").val('Europe');
        $('#capital').val('Moscow');
        $('#currency').val('Russian Ruble');
        $('#pm-name').val('Dmitry Medvedev');
   }
    //if option value Australia
   else if($(this).children('option:selected').val() === 'Australia')
   {
        $("#continent").val('Oceania');
        $('#capital').val('Canberra');
        $('#currency').val('Australian Dollar');
        $('#pm-name').val('Scott Morrison');
   }
   //else clear the fields
   else
   {
        $.each(fields, function(){
            $(this).val("");
        });
    }
})

