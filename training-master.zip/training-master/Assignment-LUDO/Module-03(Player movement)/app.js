/* module - 01 : dice;
   module - 02 : user interface of the game
   module - 03(a) : movement function;
            03(b) : movement function for active markers;
   module - 04(a) : collision function for different color markers in the same block;
            04(b) : collision function(conurrent) for same color markers int same block; 
*/

//variables
let p1;
let p2;
$btnp1 = $('.btnp1');                                                                     //dice player 1                                                       
$btnp2 = $('.btnp2');                                                                     //dice player 2
$btnp3 = $('.btnp3');                                                                     //dice player 3
$btnp4 = $('.btnp4');                                                                     //dice player 4                                
$btnp2.attr('disabled', 'disabled');                                                      //at start disable player 2                                            
$btnp3.attr('disabled', 'disabled');                                                      //at start disable player 3
$btnp4.attr('disabled', 'disabled');                                                      //at start disable player 4

//module - 01
//click event for dice player 1
$btnp1.off('click').on('click', function()
{
   diceRandom = Math.floor(Math.random() * 6) + 1;                                        //generate random numbers for player 1 dice                                                                                                       
   $btnp1.text(diceRandom);                                                               //text the random number on dice player 1                                                 
   let $team = $('.red-team');                                                            //team color selector(red:player1)
   let start = 'red-start';                                                               //inital position of the team(red:player1)
   let $firstPos = $('[red = 0]');                                                        //first active position of the team (red:player1)
   let diceNumber = diceRandom;                                                           //assigning random numbers(player1)   
   let color = 'red';                                                                     //team color in string(red:player1)
   team = 'red-team';                                                                     //team name in string(red:player1)
   $dice1 = $btnp1;                                                                       //assigning dice button (player1)                 
   $dice2 = $btnp3;                                                                       //next player's dice(yellow:player3)
   movementFunction($dice1, $dice2, start , $team, $firstPos, diceNumber, color, team);   //movement function call for player1
   
});

//click event for dice player 2
$btnp2.off('click').on('click',function()
{   
   diceRandom = Math.floor(Math.random() * 6) + 1;                                        //generate random numbers for player 2 dice                    
   $btnp2.text(diceRandom);                                                               //text the random number on dice player 2                                           
   $team = $('.green-team');                                                              //team color selector(green:player2)                                          
   start = 'green-start';                                                                 //inital position of the team(green:player2)
   $firstPos = $('[green = 0]');                                                          //first active position of the team (green:player2)                                      
   diceNumber = diceRandom;                                                               //assigning random numbers(player2)                                           
   color = 'green';                                                                       //team color in string(green:player2)
   team = 'green-team';                                                                   //team name in string(green:player2)
   $dice1 = $btnp2;                                                                       //assigning dice button (player2)
   $dice2 = $btnp4;                                                                       //next player's dice(violet:player4) 
   movementFunction($dice1, $dice2, start , $team, $firstPos, diceNumber, color, team)    //movement function call for player2
});

//click event for dice player 3
$btnp3.off('click').on('click',function()
{   
   diceRandom = Math.floor(Math.random() * 6) + 1;                                           //generate random numbers for player 3 dice                    
   $btnp3.text(diceRandom);                                                                  //text the random number on dice player 3                                           
   $team = $('.yellow-team');                                                                //team color selector(green:player2)                                          
   start = 'yellow-start';                                                                   //inital position of the team(yellow:player3)                                          
   $firstPos = $('[yellow = 0]');                                                            //first active position of the team (yellow:player3)                                      
   diceNumber = diceRandom;                                                                  //assigning random numbers(player3)                                           
   color = 'yellow';                                                                         //team color in string(yellow:player3)                                                    
   team = 'yellow-team';                                                                     //team name in string(yellow:player3)
   $dice1 = $btnp3;                                                                          //assigning dice button (player3)
   $dice2 = $btnp2;                                                                          //next player's dice(green:player2)
   movementFunction($dice1, $dice2, start , $team, $firstPos, diceNumber, color, team)       //movement function call for player3  
});

//click event for dice player 4
$btnp4.off('click').on('click',function()
{   
   diceRandom = Math.floor(Math.random() * 6) + 1;                                              //generate random numbers for player 4 dice                    
   $btnp4.text(diceRandom);                                                                     //text the random number on dice player 4                                          
   $team = $('.violet-team');                                                                   //team color selector(violet:player4) 
   start = 'violet-start';                                                                      //inital position of the team(violet:player4)                                            
   $firstPos = $('[violet = 0]');                                                               //first active position of the team (violet:player4)                                     
   diceNumber = diceRandom;                                                                     //assigning random numbers(player4)                                          
   color = 'violet';                                                                            //team color in string(violet:player4)
   team = 'violet-team';                                                                        //team name in string(violet:player4)
   $dice1 = $btnp4;                                                                             //assigning dice button (player4)
   $dice2 = $btnp1;                                                                             //next player's dice(red:player1)
   movementFunction($dice1, $dice2, start , $team, $firstPos, diceNumber, color, team)          //movement function call for player4  
});

//module - 03(a)
//movement function definition 
function movementFunction($dice1, $dice2, start , $team, $firstPos, diceNumber, color, team)
{
   
   if(diceNumber === 6)                                                                         //if dice valur is 6
   {  
      $team.addClass('highlight');                                                              //highlight the markers(initial position)
      $dice1.attr('disabled','disabled');                                                       //disable the current player's dice
      
      //click event for the team (highlighted)
      $team.off('click').on('click', function()
      {
         if($(this).parent().hasClass(start))                                                    //if the markers are in the initial position
         {
            $firstPos.append($(this));                                                           //append the selected marker in the first active position
            $(this).addClass('active');                                                          //activate the marker
            $dice1.removeAttr('disabled');                                                       //enable the current palyer's dice
            $team.removeClass('highlight');                                                      //remove highlight
            $team.off('click');                                                                  //disable the click
         }
         else if($(this).hasClass('active'))                   
         {
            activeMovement($(this),$dice1, $dice2, $team, diceNumber, color, team);              //movement function call for active markers
         }
      });
   }
   else if(diceNumber != 6)
   {  
      $(`.${team}.active`).addClass('highlight');                                                  //highlight all the markers that are active                               
      $dice1.attr('disabled','disabled');                                                          //disable the current Player's dice
      
      //click event on the highlighted makers
      $('.highlight').off('click').on('click', function()
      {  
         activeMovement($(this), $dice1, $dice2, $team, diceNumber, color, team);                  //movement function call for active markers
      });
      if($team.hasClass('highlight') === false)                                                    //if no markers highlighted
      {
         $dice2.removeAttr('disabled');                                                            //enable the next player's dice
      }   
   }
}


//module - 03(b)
//movement function for active markers
function activeMovement($currentMarker, $dice1, $dice2, $team, diceNumber, color, team)
{  
   if($currentMarker.siblings().length === 1)                                                        //check for the markers in the same div
   {
      $currentMarker.siblings().removeClass('fa-lg small');                                          //enlarge the markers//
      $currentMarker.siblings().addClass('fa-3x');                                                   // -""-   //
   }
   playerPos = Number($currentMarker.parent().attr(color));                                          //get the current poisition of the selected marker
   $(`[${color} = ${playerPos + diceNumber}]`).append($currentMarker);                               //append the marker to the next position 
   $team.removeClass('highlight');                                                                   //remove highlight
   if(diceNumber === 6)                                                       
   {
      $dice1.removeAttr('disabled');                                                                 //if 6 repeat chance for the current player(dice:enable)                                                          
   }
   else
   {
      $dice2.removeAttr('disabled');                                                                 //else next player's turn
   }                                                                       
   $team.off('click');                                                                               //disable click event 
   if($currentMarker.parent().not('.safe-zone').children().length > 1)                               //if two markers present in one block(div) 
   { 
      collision(team, $currentMarker);                                                               //call collision function
   }
   else
   {
      $currentMarker.siblings().removeClass('fa-lg small');                                          //else enlarge the children of the block 
      $currentMarker.removeClass('fa-lg small');
      $currentMarker.addClass('fa-3x');
      $currentMarker.siblings().addClass('fa-3x');
   }
   if($currentMarker.parent().hasClass('result'))                                                     //if the marker reached the last block
   {
      $currentMarker.removeClass('active');                                                         //deactivate the marker
      $currentMarker.removeClass(team);                                                               //remove highlight
      $currentMarker.removeClass('highlight');                                                        //remove it from the team
   }

}
//module - 04(a)
//collision definition
function collision(team,$currentMarker)
{
   if($currentMarker.siblings().hasClass(team) === false)                                   //if the two different color markers present in the same block                            
   {
      initial = $currentMarker.siblings().attr('originated');                               //get the initial position of the sibling marker 
      $currentMarker.siblings().removeClass('active');                                      //deactivate the marker             
      $(`#${initial}`).append($currentMarker.siblings());                                   //append the marker to the initial position
   }
   else
   { 
      concurrent($currentMarker);                                                            //concurrent function call (for same color markers in the block)
   }
}
//module -04(b)
//concurrent function definition
   function concurrent($currentMarker)
   {
      $currentMarker.removeClass('fa-3x');                                                     //resize all the markers present in the block 
      $currentMarker.siblings().removeClass('fa-3x');
      $currentMarker.addClass('fa-lg small');
      $currentMarker.css('right','2px');
      $currentMarker.siblings().addClass('fa-lg small');
   }

   