$(function(){
    //Query 01
    $('.box-01').click(function(){
        $(this).css('background' , '#000');
    });
    //Query 02
    $('.box-02').click(function(){
        $(this).html('On click the text changed.')
    });
    //Query 03

    $('.box-03').click(function(){
        $('.box-03').after(`<div class="box-03"></div>`);
    });
    //Query 04
    $('.button').click(function(){
        $('.box-04.red').css('background', 'red');
    });
    //Query 05
    $('.button-disable').click(function(){
        $(this).attr('disabled',true);
    });

    //Query 06
    $('.check-button').click(function(){
        var this123=$(this);
        $(".check").each(function(){
            if(this123.attr('checked'))
            {
                this123.removeAttr('checked');
            }
        });
    });
    //Query 07
    const subdiv = $('.subdiv');
    $('.move').click(function(){
        $('.div1 .subdiv').remove();
        $('.div2').append(subdiv);
        
    });

    //Query 08
    $('.disable-textbox').click(function(){
        $('#textbox').attr('readonly','true');
    });

    //Query 09
    $('.select-3').click(function(){
        $('#dropdown').val('three');
    });

    //Query10
    $('.increase-size').click(function(){
        $('.box-10').css({'height':'200px','width':'200px'});
    });    
    //Query 11
    $('.remove-button').click(function(){
        $(this).remove();
    });
    //Query 12
    $('.alert-btn').click(function(){
        setTimeout(displayAlert, 3000);
    });
    function displayAlert(){
      alert('this is an alert');
    }
    //Query 13
    $('#childCount').click(function(){
       $('.box-13').html($('.box-13').children().length);
    });
    //Query 14
    $('.resize').click(function(){
        $('.box-14').animate({height:'500px',width:"500px"});
    });
    //Query15
    $('#empty').click(function(){
       $('.box-15').each(function(){
        if($(this).children().length > 0)
        {
            $(this).show();
        }
        else{
            $(this).hide();
        }
       });
    });
    //Query 16
    $('#h2').click(function(){
        $('#h4').replaceWith('<h2>This is a text in h2</h2>');
    });   
    //Query 17
    $('#clear-all').click(function(){
        $('.header').hide();
     $('.heading').find('h3').show();
    });
});